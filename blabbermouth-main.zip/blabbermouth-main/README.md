# Document QA

<div align=center>
  <img src="https://github.com/kanugurajesh/Document-QA/assets/77529419/da7d4c4d-3155-4f3a-bfe9-5e85919f59fa" alt="" width=150 height=150>
</div>

A document Question Answering application using Gemini Pro vision. This project provides good user interface to interact with gemini pro vision

## Screenshots

![Screenshot 2024-01-18 215141](https://github.com/kanugurajesh/Document-QA/assets/77529419/0e4e29db-e862-4cc6-8bbf-ca3da288349e)

![Screenshot 2024-01-18 215207](https://github.com/kanugurajesh/Document-QA/assets/77529419/43247e8e-4f1a-42f2-a9b1-4d3667b20ce1)

## Demo

[![Document QA](https://img.youtube.com/vi/mQNUb9Mh2TE/0.jpg)](https://youtu.be/mQNUb9Mh2TE)

